<?php

    $source = "mysql:host=localhost;dbname=activity";
    $username = "root";
    $password = "";

    try {
        $pdo = new PDO($source, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        echo "Connection failed: ". $e->getMessage();
    }