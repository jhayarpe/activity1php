<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];
    $email = $_POST['email'];
    $firstName = $_POST['firstname'];
    $middleName = $_POST['middlename'];
    $lastName = $_POST['lastname'];
    $suffix = $_POST['suffix'];
    $birthday = $_POST['birthday'];
    $address = $_POST['address'];
    $contactNumber = $_POST['contact_number'];

    $targetDirectory = "uploads/"; 
    $targetFile = $targetDirectory . basename($_FILES["profile_picture"]["name"]); 
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    if (!file_exists($targetDirectory)) {
        mkdir($targetDirectory, 0777, true);
    }


    if ($uploadOk == 0) {
        die("Sorry, your file was not uploaded.");
    } else {
        if (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $targetFile)) {
            echo "The file ". htmlspecialchars( basename( $_FILES["profile_picture"]["name"])). " has been uploaded.";
        } else {
            die("Sorry, there was an error uploading your file.");
        }
    }

    if ($password !== $confirmPassword) {
        die("Passwords do not match");
    }

    try {
        require_once "dbc.inc.php";

        $query = "INSERT INTO useraccount(userName, userPassword, userConfirmPass, userEmail, firstName, middleName, lastName, suffix, birthday, address, contactNumber, img) VALUES(:userName, :userPassword, :userConfirmPass, :userEmail, :firstName, :middleName, :lastName, :suffix, :birthday, :address, :contactNumber, :profilePicture)";
    
        $stmt = $pdo->prepare($query);

        $hashedPass = password_hash($password, PASSWORD_DEFAULT);

        $stmt->bindParam(":userName", $username);
        $stmt->bindParam(":userPassword", $hashedPass);
        $stmt->bindParam(":userConfirmPass", $confirmPassword);
        $stmt->bindParam(":userEmail", $email);
        $stmt->bindParam(":firstName", $firstName);
        $stmt->bindParam(":middleName", $middleName);
        $stmt->bindParam(":lastName", $lastName);
        $stmt->bindParam(":suffix", $suffix);
        $stmt->bindParam(":birthday", $birthday);
        $stmt->bindParam(":address", $address);
        $stmt->bindParam(":contactNumber", $contactNumber);
        $stmt->bindParam(":profilePicture", $targetFile); 

        $stmt->execute();

        $pdo = null;
        $stmt = null;

        header("Location: ../register.php");
        die();
    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("Location: ../index.php");
}
