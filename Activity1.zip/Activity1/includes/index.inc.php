<?php
var_dump($_POST);
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $username = $_POST['username'];
        $password = $_POST['password']; 

        if(empty($username) || empty($password)){
            echo "Invalid username or password";
        }
        else{
            try{
                require_once "dbc.inc.php";

                $query = "SELECT * FROM useraccount WHERE username = :username";
                
                $stmt = $pdo->prepare($query);

                $stmt -> bindParam(":username", $username);
                $stmt->execute();

                $result = $stmt->fetch(PDO::FETCH_ASSOC);

                if($result){
                    $hashedPass = $result["password"];
                    $verify = password_verify($password,$hashedPass);
                    
                    if($verify){
                        $pdo = null;
                        $stmt=null;

                        header("Location: ../dashboard.php");
                        die();
                    }else{
                        echo "Password doesn't match";
                    }
                }else{
                    echo "Username doesn't match";
                }
            }catch(PDOException $e){
                echo "Query failed" . $e->getMessage();
            }
        }
    }else{
        header("Location: ../index.php");
    }